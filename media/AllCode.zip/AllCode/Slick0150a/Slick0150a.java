//34567890123456789012345678901234567890123456789012345678
//======================================================//
/*Slick0150a.java
Copyright 2012, R.G.Baldwin

Cause a ladybug sprite to bounce around inside the game
window.

Tested using JDK 1.7 under WinXP
*********************************************************/

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

public class Slick0150a extends BasicGame{
  
  Image bug = null;
  Image background = null;
  
  float backgroundWidth;
  float backgroundHeight;
  
  float bugX = 100;
  float bugY = 100;
  float bugWidth;
  float bugHeight;
  
  float bugXDirection = 1.0f;//initial direction to right
  float bugYDirection = 1.0f;//initial direction is down
  
  float xStep = 4.0f;//horizontal step size
  float yStep = 3.0f;//vertical step size
  
  float bugScale = 0.75f;//drawing scale factor
  
  //Used to compute and display the time required for the
  // bug to make each round trip across the game window
  // and back.
  long oldTime = 0;
  long traversalTime = 0;
  
  //Frame rate we would like to see and maximum frame
  // rate we will allow.
  int targetFPS = 60;
  //----------------------------------------------------//

  public Slick0150a(){//constructor
    //Set the title
    super("Slick0150a, baldwin");
  }//end constructor
  //----------------------------------------------------//

  public static void main(String[] args)
                                    throws SlickException{
    AppGameContainer app = new AppGameContainer(
                          new Slick0150a(),414,307,false);
    app.start();
  }//end main
  //----------------------------------------------------//

  @Override
  public void init(GameContainer gc)
                                   throws SlickException {
    oldTime = gc.getTime();

    bug = new Image("ladybug.png");
    background = new Image("background.jpg");
    
    backgroundWidth = background.getWidth();
    backgroundHeight = background.getHeight();
    
    bugWidth = bug.getWidth()*bugScale;
    bugHeight = bug.getHeight()*bugScale;
    
    System.out.println(
                   "backgroundWidth: " + backgroundWidth);
    System.out.println(
                 "backgroundHeight: " + backgroundHeight);
    System.out.println("bugWidth: " + bugWidth);
    System.out.println("bugHeight: " + bugHeight);
    
    gc.setTargetFrameRate(targetFPS);//set frame rate
  }//end init
  //----------------------------------------------------//

  @Override
  public void update(GameContainer gc, int delta)
                                    throws SlickException{
    //Compute new location for the sprite.
    
    //The following code assumes a constant frame rate
    // and does not correct for variations in delta.
    // The step size is always the same regardless of
    // delta (how often the steps are taken).
    bugX += bugXDirection*xStep;
    bugY += bugYDirection*yStep;
    
    //Test for collisions with the sides of the game
    // window and reverse direction when a collision
    // occurs.
    if(bugX+bugWidth >= backgroundWidth){
      //A collision has occurred.
      bugXDirection = -1.0f;//reverse direction
      //Set the position to the right edge less the width
      // of the sprite.
      bugX = backgroundWidth - bugWidth;
      
      //Compute traversal time for the bug to make one
      // round trip across the game window and back.
      long currentTime = gc.getTime();
      traversalTime = currentTime - oldTime;
      oldTime = currentTime;
    }//end if
    
    //Continue testing for collisions with the edges.
    if(bugX <= 0){
      bugXDirection = 1.0f;
      bugX = 0;
    }//end if
    
    if(bugY+bugHeight >= backgroundHeight){
      bugYDirection = -1.0f;
      bugY = backgroundHeight - bugHeight;
    }//end if
    
    if(bugY <= 0){
      bugYDirection = 1.0f;
      bugY = 0;
    }//end if
    
  }//end update
  //----------------------------------------------------//

  public void render(GameContainer gc, Graphics g)
                                    throws SlickException{
    //set the drawing mode to honor transparent pixels
    g.setDrawMode(g.MODE_NORMAL);
    
    //Draw the background to erase the previous picture.
    background.draw(0,0);
    
    //Draw the bug in its new location.
    bug.draw(bugX,bugY,bugScale);
    
    //Display the traversal time computed in the update
    // method.
    g.drawString(
                "traversalTime: "+traversalTime,100f,10f);

  }//end render

}//end class Slick0150a
//======================================================//