//34567890123456789012345678901234567890123456789012345678
//======================================================//
/*Slick0160b.java
Copyright 2012, R.G.Baldwin

Illustrates the drawFlash method to draw an image in
silhouette  format and to cause the silhouette  to switch
back and forth between two or more colors.

Tested using JDK 1.7 under WinXP
*********************************************************/

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Color;

public class Slick0160b extends BasicGame{
  
  Image spider = null;
  
  float spiderWidth;
  float spiderHeight;
  
  Color silohetteColor = Color.white;
  long timeAccumulator = 0;
  long flashInterval = 128;

  //Target frame rate 
  int targetFPS = 60;
  //----------------------------------------------------//

  public Slick0160b(){//constructor
    //Set the title
    super("Slick0160b, baldwin");
  }//end constructor
  //----------------------------------------------------//

  public static void main(String[] args)
                                    throws SlickException{
    AppGameContainer app = new AppGameContainer(
                          new Slick0160b(),384,240,false);
    app.start();
  }//end main
  //----------------------------------------------------//

  @Override
  public void init(GameContainer gc)
                                   throws SlickException {

    spider = new Image("spider.png");

    spiderWidth = spider.getWidth();
    spiderHeight = spider.getHeight();
  
    System.out.println("spiderWidth: " + spiderWidth);
    System.out.println("spiderHeight: " + spiderHeight);

    gc.setShowFPS(false) ;
    gc.setTargetFrameRate(targetFPS);//set frame rate
  }//end init
  //----------------------------------------------------//

  @Override
  public void update(GameContainer gc, int delta)
                                    throws SlickException{
    timeAccumulator += delta;
    if(timeAccumulator >= flashInterval){
      //Reset accumulator and change color of spider
      // silohette 
      timeAccumulator = 0;
      if(silohetteColor.equals(Color.white)){
        silohetteColor = Color.blue;
      }else{
        silohetteColor = Color.white;
      }//end if
    }//end if
  }//end update
  //----------------------------------------------------//

  public void render(GameContainer gc, Graphics g)
                                    throws SlickException{
    //set the drawing mode to honor transparent pixels
    g.setDrawMode(g.MODE_NORMAL);
    g.setBackground(Color.red);
    
    //Draw the spider.
    spider.draw(0f,0f);
    
    //Draw a white silohette of the spider.
    spider.drawFlash(133f,0f);
    
    //Draw a blue silohette of the spider.
    spider.drawFlash(266f,0f,131f,128f,Color.blue);
    
    //Cause an enlarged version of the spider to flash
    // between white and blue silohette at a rate
    // of 1/flashInterval.
    spider.drawFlash(0f,0f,262f,256f,silohetteColor);

  }//end render

}//end class Slick0160b
//======================================================//