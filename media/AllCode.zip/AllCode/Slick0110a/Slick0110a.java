//34567890123456789012345678901234567890123456789012345678
//======================================================//
/*Slick0110a.java
Copyright 2012, R.G.Baldwin

Possibly the simplest game that can be coded to use the
Slick game engine and run as a Java application.

Compile and run the program by executing the file named
CompileAndRun.bat.

Tested using JDK 1.7 under WinXP and Win 7
*********************************************************/

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Game;

public class Slick0110a implements Game{

  public static void main(String[] args)
                                    throws SlickException{
    AppGameContainer app =
                   new AppGameContainer(new Slick0110a());
    app.start();//this statement is required
  }//end main
  //----------------------------------------------------//

  public void init(GameContainer gc)
                                   throws SlickException {
  }//end init
  //----------------------------------------------------//

  public void update(GameContainer gc, int delta)
                                    throws SlickException{
  }//end update
  //----------------------------------------------------//

  public void render(GameContainer gc, Graphics g)
                                    throws SlickException{
  }//end render
  //----------------------------------------------------//
  public String getTitle(){
    return "Optional title";
  }//end getTitle
  //----------------------------------------------------//

  public boolean closeRequested(){
    return false;
  }//end closeRequested
}//end class Slick0110a
//======================================================//