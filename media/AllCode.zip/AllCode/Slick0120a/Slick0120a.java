//34567890123456789012345678901234567890123456789012345678
//======================================================//
/*Slick0120a.java
Copyright 2012, R.G.Baldwin

Skeleton code for a basic game.

Tested using JDK 1.7 under WinXP
*********************************************************/

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;

public class Slick0120a extends BasicGame{

  public Slick0120a(){
    //Call to superclass constructor is required.
    super("Slick0120a, Baldwin.");
  }//end constructor
  //----------------------------------------------------//

  public static void main(String[] args)
                                    throws SlickException{
    AppGameContainer app =
                   new AppGameContainer(new Slick0120a());
    app.start();//this statement is required
  }//end main
  //----------------------------------------------------//

  @Override
  public void init(GameContainer gc)
                                   throws SlickException {
    //No initialization needed for this program.
  }//end init
  //----------------------------------------------------//

  @Override
  public void update(GameContainer gc, int delta)
                                    throws SlickException{
    //Put game logic here
  }//end update
  //----------------------------------------------------//


  public void render(GameContainer gc, Graphics g)
                                    throws SlickException{
    //Put drawing code here.
  }//end render

}//end class Slick0120a
//======================================================//