//34567890123456789012345678901234567890123456789012345678
//======================================================//
/*Slick0130a.java
Copyright 2012, R.G.Baldwin

A very skinny Slick program. Barely more than a skeleton.

Tested using JDK 1.7 under WinXP
*********************************************************/

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;

public class Slick0130a extends BasicGame{
  
  //Instance variables for use in computing and
  // displaying total time since program start and
  // time for each frame.
  double totalTime = 0;
  int incrementalTime = 0;

  public Slick0130a(){
    //Call to superclass constructor is required.
    super("Slick0130a, Baldwin.");
  }//end constructor
  //----------------------------------------------------//

  public static void main(String[] args)
                                    throws SlickException{
    try{
      AppGameContainer app = (
                       new AppGameContainer(
                         new Slick0130a(),400,200,false));
      app.start();
    }catch(SlickException e){
      e.printStackTrace();
    }//end catch
  }//end main
  //----------------------------------------------------//

  @Override
  public void init(GameContainer gc)
                                   throws SlickException {
    //Set the frame rate in frames per second.
    gc.setTargetFrameRate(2);
    
  }//end init
  //----------------------------------------------------//

  @Override
  public void update(GameContainer gc, int delta)
                                    throws SlickException{
    //Compute and save total time since start in seconds.
    totalTime += delta/1000.0;
    
    //Save delta for display in render method.
    incrementalTime = delta;
    
  }//end update
  //----------------------------------------------------//


  public void render(GameContainer gc, Graphics g)
                                    throws SlickException{
    //Truncate totalTime to one decimal digit and
    // display
    double time = (int)(totalTime*10)/10.0;
    g.drawString("totalTime: "+time,100.0f,100.0f);
    
    //Display incremental time.
    g.drawString("incrementalTime: " + incrementalTime,
                 100.0f,120.0f);
  }//end render

}//end class Slick0130a
//======================================================//