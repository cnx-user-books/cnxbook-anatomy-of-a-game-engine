//34567890123456789012345678901234567890123456789012345678
//======================================================//
/*Slick0180.java
Copyright 2013, R.G.Baldwin

Uses one row of sprites from a sprite sheet along with
an Animation object to draw an animation of a dog playing.

By default, the program displays one cycle of five 
sprites per second. Clock time is displayed below the 
animation.

The time that each image of the dog is displayed is
independent of the frame rate. Demonstrate this by
changing the value of targetDelta and observing the
relationship between the animation times and the clock.

For best results, keep the targetDelta less than the
display time for each sprite (duration).

Tested using JDK 1.7 under WinXP
*********************************************************/

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;
import org.newdawn.slick.Animation;
import org.newdawn.slick.Color;

public class Slick0180 extends BasicGame{
  Image spriteSheetImage = null;

  float spriteSheetWidth;
  float spriteSheetHeight;
  int spritesPerRow = 5;
  int spritesPerColumn = 2;

  int targetDelta = 16;//msec
  int duration = 200;//time to display each sprite
  long totalTime = 0;//accumulate total time for display

  SpriteSheet spriteSheet;
  Animation animation;

  int spriteWidth;
  int spriteHeight;

  float spriteX = 0;//sprite drawing location
  float spriteY = 0;
  //----------------------------------------------------//
  public Slick0180(){
    //Call to superclass constructor is required.
    super("Slick0180, Baldwin.");
  }//end constructor
  //----------------------------------------------------//

  public static void main(String[] args)
                                    throws SlickException{
    AppGameContainer app = new AppGameContainer(
                          new Slick0180(),450,120,false);
    app.start();//this statement is required
  }//end main
  //----------------------------------------------------//

  @Override
  public void init(GameContainer gc)
                                   throws SlickException {
    spriteSheetImage = new Image("Slick0180a1.png");
    //Enlarge the sprite sheet.
    Image temp = spriteSheetImage.getScaledCopy(580,224);
    spriteSheetImage = temp;

    spriteSheetWidth = spriteSheetImage.getWidth();
    spriteSheetHeight = spriteSheetImage.getHeight();

    System.out.println(
               "spriteSheetWidth: " + spriteSheetWidth);
    System.out.println(
               "spriteSheetHeight: " + spriteSheetHeight);
    spriteWidth = (int)(spriteSheetWidth/spritesPerRow);
    spriteHeight =
                (int)(spriteSheetHeight/spritesPerColumn);

    //Instantiate a new spriteSheet object based on the
    // width and height of the tiles.
    spriteSheet = new SpriteSheet(spriteSheetImage,
                                  spriteWidth,
                                  spriteHeight);

    //Create a new animation based on a selection of
    // sprites from the spritesheet.
    animation = new Animation(spriteSheet,
                              0,//first column
                              0,//first row
                              4,//last column
                              0,//last row
                              true,//horizontal
                              duration,//display time
                              true//autoupdate
                              );

    gc.setShowFPS(true);//show FPS
    ////set frame rate
    gc.setTargetFrameRate((int)(1000/targetDelta));

    //set drawing location
    spriteX = spriteWidth;
    spriteY = 0;
  }//end init
  //----------------------------------------------------//

  @Override
  public void update(GameContainer gc, int delta)
                                    throws SlickException{
    //Note that the following is for clock time display
    // only. It does not effect the animation.
    totalTime += delta;//update total time accumulator
  }//end update
  //----------------------------------------------------//


  public void render(GameContainer gc, Graphics g)
                                    throws SlickException{
    g.setDrawMode(g.MODE_NORMAL);
    g.setBackground(Color.gray);

    //Draw the currently selected animation image at the
    // specified location
    animation.draw(spriteX,spriteY);

    g.drawString("totalTime = "+totalTime/1000,10f,100f);
  }//end render

}//end class Slick0180
//======================================================//