//34567890123456789012345678901234567890123456789012345678
//======================================================//
/*Slick0200.java
Copyright 2013, R.G.Baldwin

This program shows a baseball coach being attacked by a 
swarm of vicious ladybugs.

This program uses the class named Sprite01 to populate
the game window with 1000 ladybug sprites in differennt
colors with different sizes that fly around the game
window in different directions with different speeds.

Tested using JDK 1.7 under WinXP
*********************************************************/

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Color;

import java.util.Random;

public class Slick0200 extends BasicGame{
  
  //Store references to Sprite01 objects here.
  Sprite01[] sprites = new Sprite01[1000];
  
  //Populate this with a ladybug image later.
  Image image = null;
  
  //Populate these variables with the background
  // image along with the width and height of the
  // image later.
  Image background = null;
  float backgroundWidth;
  float backgroundHeight;
  
  //This object produces random float values for a
  // variety of purposes.
  Random random = new Random();
  
  //Frame rate we would like to see and maximum frame
  // rate we will allow.
  int targetFPS = 60;
  //----------------------------------------------------//

  public Slick0200(){//constructor
    //Set the title
    super("Slick0200, baldwin");
  }//end constructor
  //----------------------------------------------------//

  public static void main(String[] args)
                                    throws SlickException{
    AppGameContainer app = new AppGameContainer(
                          new Slick0200(),414,307,false);
    app.start();
  }//end main
  //----------------------------------------------------//

  @Override
  public void init(GameContainer gc)
                                   throws SlickException {

    //Create and save the background image object. Also
    // compute and save the width and height of the image.
    background = new Image("background.jpg");
    backgroundWidth = background.getWidth();
    backgroundHeight = background.getHeight();

    //Create and save an Image object of a ladybug. The
    // sprites will wear this image
    image = new Image("ladybug.png");

    //Populate the array with references to objects of
    // the Sprite01 class.
    for(int cnt = 0;cnt < sprites.length;cnt++){
      sprites[cnt] = new Sprite01(
         image,//ladybug image
         backgroundWidth/2.0f,//initial position
         backgroundHeight/2.0f,//initial position
         (random.nextFloat() > 0.5) ? 1f : -1f,//direction
         (random.nextFloat() > 0.5) ? 1f : -1f,//direction
         0.1f+random.nextFloat()*2.0f,//step size
         0.1f+random.nextFloat()*2.0f,//step size
         random.nextFloat()*0.15f,//scale
         new Color(random.nextFloat(),//color filter
                   random.nextFloat(),
                   random.nextFloat())); 
    }//end for loop

    gc.setTargetFrameRate(targetFPS);//set frame rate

  }//end init
  //----------------------------------------------------//

  @Override
  public void update(GameContainer gc, int delta)
                                    throws SlickException{

    //Do the following for every sprite in the array
    for(int cnt = 0;cnt < sprites.length;cnt++){
      //Ask each sprite to move.
      sprites[cnt].move();

      //Ask each sprite to bounce off the edge if
      // necessary.
      sprites[cnt].edgeBounce(
                        backgroundWidth,backgroundHeight);
    }//end for loop

  }//end update
  //----------------------------------------------------//

  public void render(GameContainer gc, Graphics g)
                                    throws SlickException{

    //set the drawing mode to honor transparent pixels
    g.setDrawMode(g.MODE_NORMAL);

    //Draw the background to erase the previous picture.
    background.draw(0,0);

    //Draw every sprite in the array.
    for(int cnt = 0;cnt < sprites.length;cnt++){
      //Ask the sprite to draw itself.
      sprites[cnt].draw();
    }//end for loop
  }//end render

}//end class Slick0200
//======================================================//