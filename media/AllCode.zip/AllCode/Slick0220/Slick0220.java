//34567890123456789012345678901234567890123456789012345678
//======================================================//
/*Slick0220.java
Copyright 2013, R.G.Baldwin

This program simulates the propagation of a fatal
communicable disease within a population.

A single infected sprite is introduced into a large 
population of sprites. The disease is spread by physical
contact with an infected sprite.

You can watch as the disease either spreads and kills the
entire population or spreads for awhle, then recedes and
dies out. Infected sprites are colored red. Healthy 
sprites are colored green. A sound is emitted (for drama)
each time there is contact between an infected sprite and
a healthy sprite.

The final outcome is determined both by chance and by 
several factors including:

-The maximum life expectancy of an infected sprite
-The maximum probability of infection due to contact with
an infected sprite
-The maximum degree of mobility of both infected and 
healthy sprites
-The population density of sprites.

The actual values for the first three factors for each 
individual are determined by the maximum value multiplied
by a random number between 0 and 1.0.

Instance variables are provided for each of these factors.
You can modify the values and recompile the program to 
experiment with different combinations of the factors.

A good exercise for a student would be to create a GUI 
that allows the factors to be entered more easily for
purposes of experimentation.

Tested using JDK 1.7 under WinXP
*********************************************************/

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Color;
import org.newdawn.slick.Sound;

import java.util.Random;
import java.util.ArrayList;
import java.util.Iterator;

public class Slick0220 extends BasicGame{
  
  //The values of the following variables can be changed
  // to effect the spread of the disease.
  
  //Set the life expentency of an infected sprite
  // in frames.
  int infectedSpriteLife = 96;
  
  //Set the maximum fraction of exposed sprites that will
  // become infected.
  float probabilityOfInfection = 0.5f;
  
  //Set the maximum step size that a sprite will move in
  // one frame.
  float maxStepSize = 1;
  
  //Set the initial number of sprites in the population.
  int numberSprites = 1000;
  
  //References to Sprite01 objects are stored here.
  ArrayList <Sprite01> sprites = 
                                new ArrayList<Sprite01>();
  
  //These variables are populated with references to Image
  // objects later.
  Image redBallImage;
  Image greenBallImage;
  
  //This variable is populated with a reference to a Sound
  // object later.
  Sound blaster;
  
  //These variables are populated with information about
  // the background image later.
  Image background = null;
  float backgroundWidth;
  float backgroundHeight;
  
  //This object is used to produce random values for a
  // variety of purposes.
  Random random = new Random();
  
  //This is the frame rate we would like to see and
  // the maximum frame rate we will allow.
  int targetFPS = 24;
  //----------------------------------------------------//

  public Slick0220(){//constructor
    //Set the title
    super("Slick0220, baldwin");
  }//end constructor
  //----------------------------------------------------//

  public static void main(String[] args)
                                    throws SlickException{
    AppGameContainer app = new AppGameContainer(
                           new Slick0220(),500,500,false);
    app.start();
  }//end main
  //----------------------------------------------------//

  @Override
  public void init(GameContainer gc)
                                   throws SlickException {

    //Create Image objects that will be used to visually
    // represent the sprites.
    redBallImage = new Image("redball.png");
    greenBallImage = new Image("greenball.png");
    
    //Create a Sound object.
    blaster = new Sound("blaster.wav");

    //Create a background image and save information
    // about it.
    background = new Image("background01.jpg");
    backgroundWidth = background.getWidth();
    backgroundHeight = background.getHeight();
    
    //Add a red sprite as the first element in the
    // ArrayList object. This sprite carries the disease
    // into the population. 
    //Put it in the center of the game window. Make the
    // direction of motion random. Make the speed of
    // motion (step size)random. Make the size random.
    // Specify a white (do nothing)color filter.
    sprites.add(new Sprite01(
       redBallImage,//image
       backgroundWidth/2.0f,//initial position
       backgroundHeight/2.0f,//initial position
       (random.nextFloat() > 0.5) ? 1f : -1f,//direction
       (random.nextFloat() > 0.5) ? 1f : -1f,//direction
       0.1f+random.nextFloat()*2.0f,//step size
       0.1f+random.nextFloat()*2.0f,//step size
       0.5f+random.nextFloat()*0.5f,//scale
       new Color(1.0f,1.0f,1.0f)));//color filter

    //This is an infected object. Set its life
    // expectancy.
    sprites.get(0).setLife(
            (int)(random.nextFloat()*infectedSpriteLife));

    //Populate the ArrayList object with green sprites.
    // Make the initial position random. Make the initial
    // direction of motion random. Make the speed
    // (step size) random. Make the size (scale) random.
    // Make the color filter white (do nothing).
    for(int cnt = 0;cnt < numberSprites;cnt++){
      sprites.add(new Sprite01(
         greenBallImage,//image
         backgroundWidth*random.nextFloat(),//position
         backgroundHeight*random.nextFloat(),//position
         (random.nextFloat() > 0.5) ? 1f : -1f,//direction
         (random.nextFloat() > 0.5) ? 1f : -1f,//direction
         random.nextFloat()*maxStepSize,//step size
         random.nextFloat()*maxStepSize,//step size
         1.0f,//scale
         new Color(1.0f,1.0f,1.0f)));//color filter 
    }//end for loop

    gc.setTargetFrameRate(targetFPS);//set frame rate

  }//end init
  //----------------------------------------------------//

  @Override
  public void update(GameContainer gc, int delta)
                                    throws SlickException{

    //Move all the sprites to their new positions.
    for(int cnt = 0;cnt < sprites.size();cnt++){
      //Get a reference to the current Sprite01 object.
      Sprite01 thisSprite = sprites.get(cnt);
      //Ask the sprite to move according to its
      // properties
      thisSprite.move();

      //Ask the sprite to bounce off the edge if necessary
      thisSprite.edgeBounce(
                        backgroundWidth,backgroundHeight);
    }//end for loop

    //Search for and process collisions between
    // infected (red) sprites and healthy (green)
    // sprites. Declare the green sprite to be exposed to
    // the disease when a collision occurs.
    for(int ctr = 0;ctr < sprites.size();ctr++){
      //Get a reference to the Sprite01 object.
      Sprite01 testSprite = sprites.get(ctr);

      if(testSprite.getImage().equals(redBallImage)){
        //This is an infected sprite. Reduce its life.
        testSprite.setLife(testSprite.getLife() - 1);
      
        // Do the following for every sprite in the
        // ArrayList object.
        for(int cnt = 0;cnt < sprites.size();cnt++){
          //Get a reference to the Sprite01 object.
          Sprite01 thisSprite = sprites.get(cnt);
          
          //Test for a collision between this sprite and
          // the infected test sprite.
          boolean collision = 
                       thisSprite.isCollision(testSprite);
    
          //Process a collision if it has occurred.
          // Exclude collisions between the testSprite
          // and itself and with other infected sprites.

          if((collision == true)&&(!thisSprite.getImage().
                                   equals(redBallImage))){

            //A collision has occured, set exposed to true
            thisSprite.setExposed(true);

            //Play a sound to indicate that a collision
            // has occurred.
            blaster.play();
          }//end if
    
        }//end for loop
      }//end if on redBallImage
      
      //Make a cleanup pass through the ArrayList object
      Iterator <Sprite01> iterB = sprites.iterator();
  
      while(iterB.hasNext()){
        Sprite01 theSprite = iterB.next();
        
        //Cause a percentage of the exposed objects to
        // contract the disease. Clear the others. 
        if((theSprite.getExposed() == true) && 
           (random.nextFloat() < probabilityOfInfection)){
          theSprite.setImage(redBallImage);
          theSprite.setLife((int)(
                  random.nextFloat()*infectedSpriteLife));
          theSprite.setExposed(false);
        }else{
          //Eliminate the effects of the exposure
          theSprite.setExposed(false);
        }//end else
        
        //Remove dead sprites
        if(theSprite.getLife() <= 0){
          iterB.remove();
        }//end if
      }//end while loop
      
    }//end outer for loop

  }//end update
  //----------------------------------------------------//

  public void render(GameContainer gc, Graphics g)
                                    throws SlickException{

    //set the drawing mode to honor transparent pixels
    g.setDrawMode(g.MODE_NORMAL);

    //Draw the background to erase the previous picture.
    background.draw(0,0);

    //Draw every sprite in the ArrayList object.
    for(int cnt = 0;cnt < sprites.size();cnt++){
      sprites.get(cnt).draw();
    }//end for loop
    
    //Display the number of sprites remaining.
    g.drawString(
       "Sprites remaining: " + (sprites.size()),100f,10f);
  }//end render

}//end class Slick0220
//======================================================//