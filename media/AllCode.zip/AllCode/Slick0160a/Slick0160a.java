//34567890123456789012345678901234567890123456789012345678
//======================================================//
/*Slick0160a.java
Copyright 2012, R.G.Baldwin

Calls the draw method several times in succession to
illustrate the various options available with the draw
method. Also illustrates flipping an image.

Tested using JDK 1.7 under WinXP
*********************************************************/

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Color;

public class Slick0160a extends BasicGame{
  
  Image rabbit = null;
  
  float rabbitWidth;
  float rabbitHeight;

  //Frame rate we would like to see and maximum frame
  // rate we will allow.
  int targetFPS = 60;
  //----------------------------------------------------//

  public Slick0160a(){//constructor
    //Set the title
    super("Slick0160a, baldwin");
  }//end constructor
  //----------------------------------------------------//

  public static void main(String[] args)
                                    throws SlickException{
    AppGameContainer app = new AppGameContainer(
                          new Slick0160a(),512,537,false);
    app.start();
  }//end main
  //----------------------------------------------------//

  @Override
  public void init(GameContainer gc)
                                   throws SlickException {

    rabbit = new Image("rabbit.png");

    rabbitWidth = rabbit.getWidth();
    rabbitHeight = rabbit.getHeight();
  
    System.out.println(
                   "rabbitWidth: " + rabbitWidth);
    System.out.println(
                 "rabbitHeight: " + rabbitHeight);

    gc.setShowFPS(false) ;
    gc.setTargetFrameRate(targetFPS);//set frame rate
  }//end init
  //----------------------------------------------------//

  @Override
  public void update(GameContainer gc, int delta)
                                    throws SlickException{
  }//end update
  //----------------------------------------------------//

  public void render(GameContainer gc, Graphics g)
                                    throws SlickException{
    //set the drawing mode to honor transparent pixels
    g.setDrawMode(g.MODE_NORMAL);
    g.setBackground(Color.white);
    
    rabbit.draw(0f,0f);
    rabbit.draw(133f,0f,new Color(1.0f,0.0f,1.0f));
    rabbit.draw(266f,0f,0.5f);
    rabbit.draw(335f,0f,128f,192);
    
    rabbit.draw(0f,133f);
    rabbit.draw(133f,133f,32f,32f,96f,96f);
    rabbit.draw(0f,266f,256f,532f,32f,32f,96f,96f,new Color(1.0f,1.0f,0.0f));
    
    rabbit.drawCentered(399f,266f);
    

    Image tempImage = rabbit.getFlippedCopy(true,false);
//    tempImage.rotate(45f);
    tempImage.draw(266f,399f);

  }//end render

}//end class Slick0160a
//======================================================//