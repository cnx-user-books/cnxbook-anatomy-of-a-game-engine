//34567890123456789012345678901234567890123456789012345678
//======================================================//
/*Slick0170java
Copyright 2013, R.G.Baldwin

Cause a ladybug sprite to move inside the game window by
pressing the arrow keys or the left and right mouse
buttons. The mouse pointer must be inside the game window
for the mouse buttons to move the sprite.

Right arrow or right mouse button: move right
Left arrow or left mouse button: move left
Up arrow: move up
Down arrow: move down

The program also gets and displays the X and Y 
coordinates of the mouse pointer.

Much of this program is identical to the earlier program
named Slick0150a.java.

Tested using JDK 1.7 under WinXP
*********************************************************/

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.Input;

public class Slick0170 extends BasicGame{
  
  Image bug = null;
  Image background = null;
  
  float backgroundWidth;
  float backgroundHeight;
  
  float bugX = 100;
  float bugY = 100;
  float bugWidth;
  float bugHeight;
  
  float xStep = 4.0f;//horizontal step size
  float yStep = 3.0f;//vertical step size
  
  float bugScale = 0.75f;//drawing scale factor
  
  //Frame rate we would like to see and maximum frame
  // rate we will allow.
  int targetFPS = 60;
  
  //This is new code relative to Slick0150a.java
  int mouseX = 0;
  int mouseY = 0;
  //----------------------------------------------------//

  public Slick0170(){//constructor
    //Set the title
    super("Slick0170, baldwin");
  }//end constructor
  //----------------------------------------------------//

  public static void main(String[] args)
                                    throws SlickException{
    AppGameContainer app = new AppGameContainer(
                          new Slick0170(),414,307,false);
    app.start();
  }//end main
  //----------------------------------------------------//

  @Override
  public void init(GameContainer gc)
                                   throws SlickException {
    bug = new Image("ladybug.png");
    background = new Image("background.jpg");
    
    backgroundWidth = background.getWidth();
    backgroundHeight = background.getHeight();
    
    bugWidth = bug.getWidth()*bugScale;
    bugHeight = bug.getHeight()*bugScale;
    
    System.out.println(
                   "backgroundWidth: " + backgroundWidth);
    System.out.println(
                 "backgroundHeight: " + backgroundHeight);
    System.out.println("bugWidth: " + bugWidth);
    System.out.println("bugHeight: " + bugHeight);
    
    gc.setTargetFrameRate(targetFPS);//set frame rate
  }//end init
  //----------------------------------------------------//

  @Override
  public void update(GameContainer gc, int delta)
                                    throws SlickException{
    //Most of the code in this method is different from
    // the code in Slick0150a.java.
    
    //Get a reference to the Input object.
    Input input = gc.getInput();
    
    //Control horizontal bug position by pressing the
    // arrow keys or pressing the left and right mouse
    // buttons.
    if(input.isKeyDown(Input.KEY_RIGHT) || 
       input.isMouseButtonDown(Input.MOUSE_RIGHT_BUTTON)){
      bugX += xStep;
    }//end if
    
    if(input.isKeyDown(Input.KEY_LEFT) || 
        input.isMouseButtonDown(Input.MOUSE_LEFT_BUTTON)){
      bugX -= xStep;
    }//end if
    
    //Control vertical bug position by pressing the arrow
    // keys. Vertical bug position cannot be controlled by
    // pressing mouse buttons.
    if(input.isKeyDown(Input.KEY_UP)){
      bugY -= yStep;
    }//end if
    
    if(input.isKeyDown(Input.KEY_DOWN)){
      bugY += yStep;
    }//end if
    
    //Test for collisions with the sides of the game
    // window and stop moving the bug when a collision
    // occurs.
    if(bugX + bugWidth >= backgroundWidth){
      //Set the position to the right edge less the width
      // of the sprite.
      bugX = backgroundWidth - bugWidth;
    }//end if
    
    //Continue testing for collisions with the edges.
    if(bugX <= 0){
      bugX = 0;
    }//end if
    
    if(bugY + bugHeight >= backgroundHeight){
      bugY = backgroundHeight - bugHeight;
    }//end if
    
    if(bugY <= 0){
      bugY = 0;
    }//end if
    
    //Get and save the X and Y coordinates of the mouse
    // pointer.
    mouseX = input.getMouseX();
    mouseY = input.getMouseY();
    
  }//end update
  //----------------------------------------------------//

  public void render(GameContainer gc, Graphics g)
                                    throws SlickException{
    //set the drawing mode to honor transparent pixels
    g.setDrawMode(g.MODE_NORMAL);
    
    //Draw the background to erase the previous picture.
    background.draw(0,0);
    
    //Draw the bug in its new location.
    bug.draw(bugX,bugY,bugScale);
    
    //Display the location of the mouse pointer. This is
    // new code relative to Slick0150a.java
    g.drawString(
               "X: " + mouseX + " Y: " + mouseY,100f,10f);
  }//end render

}//end class Slick0170
//======================================================//