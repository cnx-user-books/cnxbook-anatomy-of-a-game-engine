//34567890123456789012345678901234567890123456789012345678
//======================================================//
/*Slick0140a.java
Copyright 2012, R.G.Baldwin

Illustrates drawing a sprite image with transparent 
parts on a background image using two different 
approaches.

Tested using JDK 1.7 under WinXP
*********************************************************/

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

public class Slick0140a extends BasicGame{

  Image ladybug = null;
  Image background = null;
  float leftX = 100;//leftmost position of ladybug
  float leftY = 100;
  
  float middleX = 200;//middle position of ladybug
  float middleY = 50;
  
  float rightX = 300;//rightmost position of ladybug
  float rightY = 100;
  
  
  float leftScale = 0.75f;//drawing scale factors
  float rightScale = 1.25f;
  //----------------------------------------------------//

  public Slick0140a(){//constructor
    //Set the title
    super("Slick0140a, baldwin");
  }//end constructor
  //----------------------------------------------------//

  public static void main(String[] args)
                                    throws SlickException{
    AppGameContainer app = new AppGameContainer(
                          new Slick0140a(),414,307,false);
    app.start();
  }//end main
  //----------------------------------------------------//

  @Override
  public void init(GameContainer gc)
                                   throws SlickException {
    ladybug = new Image("ladybug.png");
    background = new Image("background.jpg");
    gc.setShowFPS(false);//disable FPS display
    gc.setTargetFrameRate(60);//set frame rate
  }//end init
  //----------------------------------------------------//

  @Override
  public void update(GameContainer gc, int delta)
                                    throws SlickException{
    //No updates required in this program.
  }//end update
  //----------------------------------------------------//

  public void render(GameContainer gc, Graphics g)
                                    throws SlickException{
    //Note that the names of the drawMode constants seem
    // to be backwards.
    
    //Draw the background and two versions of the 
    // ladybug by calling a draw method of the Image
    // class.
    g.setDrawMode(g.MODE_NORMAL);//honors transparency
    background.draw(0,0);
    ladybug.draw(leftX,leftY,leftScale);

    g.setDrawMode(g.MODE_ALPHA_BLEND);//no transparency
    ladybug.draw(rightX,rightY,rightScale);
    
    //Draw a third version of the ladybug by calling
    // a drawImage method of the Graphics class.
    g.setDrawMode(g.MODE_NORMAL);
    g.drawImage(ladybug,middleX,middleY);
  }//end render

}//end class Slick0140a
//======================================================//