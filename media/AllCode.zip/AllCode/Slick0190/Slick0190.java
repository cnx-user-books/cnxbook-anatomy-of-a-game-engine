//34567890123456789012345678901234567890123456789012345678
//======================================================//
/*Slick0190.java
Copyright 2013, R.G.Baldwin

Fairly complex animation using a sprite sheet.

Sprite moves to right during first third of the 
animation. Sprite remains stationary during second third
of the animation. Sprite moves to the left back to the
starting point during the last third of the animation.

Much more complicated than Slick0180 for several reasons
including the following:

The sprite is moved horizontally during a portion but not
all of the animation. Movement must be synchronized with
the animation frame counter.

The sprite sheet contains only images of the dog facing
to the left. However, images of the dog facing to the
right are also required. This requires that each image
on the sprite sheet be extracted and flipped horizontally
before being fed to the Animation object for half of
the animation sequence.

The display duration for images from the first row is 
shorter than for images from the second row.

Tested using JDK 1.7 under WinXP
*********************************************************/

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;
import org.newdawn.slick.Animation;
import org.newdawn.slick.Color;

public class Slick0190 extends BasicGame{
  Image spriteSheetImage = null;

  float spriteSheetWidth;
  float spriteSheetHeight;
  int spritesPerRow = 5;
  int spritesPerColumn = 2;
  int spriteWidth;
  int spriteHeight;

  int targetDelta = 16;//msec
  SpriteSheet spriteSheet;
  Animation animation = new Animation();

  //Horizontal and vertical crawing coordinates.
  float spriteX = 0;
  float spriteY = 0;

  //----------------------------------------------------//
  public Slick0190(){
    //Call to superclass constructor is required.
    super("Slick0190, Baldwin.");
  }//end constructor
  //----------------------------------------------------//

  public static void main(String[] args)
                                    throws SlickException{
    AppGameContainer app = new AppGameContainer(
                          new Slick0190(),450,120,false);
    app.start();//this statement is required
  }//end main
  //----------------------------------------------------//

  @Override
  public void init(GameContainer gc)
                                   throws SlickException {
    //Create a SpriteSheet object
    spriteSheetImage = new Image("Slick0190a1.png");
    //Enlarge the sprite sheet.
    Image temp = spriteSheetImage.getScaledCopy(580,224);
    spriteSheetImage = temp;

    spriteSheetWidth = spriteSheetImage.getWidth();
    spriteSheetHeight = spriteSheetImage.getHeight();
    spriteWidth = (int)(spriteSheetWidth/spritesPerRow);
    spriteHeight =
                (int)(spriteSheetHeight/spritesPerColumn);

    //Instantiate a new spriteSheet object based on the
    // width and height of the individual tiles on the
    // sheet.
    spriteSheet = new SpriteSheet(spriteSheetImage,
                                  spriteWidth,
                                  spriteHeight);

    //Populate the Animation object
    //Begin by adding four sets of five sprites from the
    // top row with the images flipped to face right.
    for(int cntr = 0;cntr < 4;cntr++){
      for(int cnt = 0;cnt < 5;cnt++){
        animation.addFrame(
              spriteSheet.getSprite(cnt,0).getFlippedCopy(
                                         true,false),100);
      }//end inner loop
    }//end outer loop
    
    //Add two sets of five sprites from the bottom row
    // with the images flipped to face right.
    for(int cntr = 0;cntr < 2;cntr++){                       
      for(int cnt = 0;cnt < 5;cnt++){
        animation.addFrame(
              spriteSheet.getSprite(cnt,1).getFlippedCopy(
                                         true,false),400);
      }//end inner loop
    }//end outer loop

    //Add two sets of five sprites from the bottom row
    // with the images facing left.
    for(int cntr = 0;cntr < 2;cntr++){
      for(int cnt = 0;cnt < 5;cnt++){
        animation.addFrame(
                        spriteSheet.getSprite(cnt,1),400);
      }//end inner loop
    }//end outer loop
    
    //Add four sets of five sprites from the top row with
    // the images facing left
    for(int cntr = 0;cntr < 4;cntr++){
      for(int cnt = 0;cnt < 5;cnt++){
        animation.addFrame(
                        spriteSheet.getSprite(cnt,0),100);
      }//end for loop
    }//end for loop

    gc.setShowFPS(true);//display FPS
    //Set frame rate
    gc.setTargetFrameRate((int)(1000/targetDelta));

  }//end init
  //----------------------------------------------------//

  @Override
  public void update(GameContainer gc, int delta)
                                    throws SlickException{

    int stepSize = 15;//Distance the sprite moves
    int frame = animation.getFrame();//animation frame
    int oneThird = animation.getFrameCount()/3;
    
    //Treat the entire animation in thirds with regard
    // to sprite movement. Move to the right during first
    // third. Stay stationary during second third. Move
    // to left back to starting point during last third.
    if(frame < oneThird){
      //Sprite is moving to the right. Compute the new
      // position.
      spriteX = frame*stepSize;
    }else if(frame < 2*oneThird){
      //Sprite is stationary. Don't change position
    }else if(frame < 3*oneThird){
      //Cause the sprite to rurn around and start
      // moving to the left toward the starting point.
      //Reduce frame count by number of frames during
      // which the sprite wasn't moving.
      frame -= oneThird;
      //Compute the new position.
      spriteX = (2*oneThird - frame)*stepSize;
    }//end else if
    
  }//end update
  //----------------------------------------------------//


  public void render(GameContainer gc, Graphics g)
                                    throws SlickException{
    g.setDrawMode(g.MODE_NORMAL);
    g.setBackground(Color.gray);
    animation.draw(spriteX,spriteY);

  }//end render

}//end class Slick0190
//======================================================//