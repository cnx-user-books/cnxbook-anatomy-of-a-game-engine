//34567890123456789012345678901234567890123456789012345678
//======================================================//
/*Slick0150b.java
Copyright 2012, R.G.Baldwin

Cause a ladybug sprite to bounce around inside the game
window.

A random time delay is inserted in the render method to
simulate a situation where the rendering process is very
complex and the time to render varies from one frame to
the next.

The program attempts to maintain a constant physical
speed as the bug moves across the game window despite
the fact that the delta varies quite a bit from one
frame to the next. The step size varies in proportion
to delta or inversely with frame rate.

Tested using JDK 1.7 under WinXP
*********************************************************/

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import java.util.Random;

public class Slick0150b extends BasicGame{
  Random random = new Random();

  Image bug = null;
  Image background = null;

  float backgroundWidth;
  float backgroundHeight;

  float bugX = 100;//initial position of ladybug
  float bugY = 100;
  float bugWidth;
  float bugHeight;

  float bugXDirection = 1.0f;//initial direction to right
  float bugYDirection = 1.0f;//initial direction is down

  float xStep = 4.0f;//horizontal step size
  float yStep = 3.0f;//vertical step size

  float bugScale = 0.75f;//drawing scale factor

  //Used to compute and display the time required for the
  // bug to make each round trip across the game window
  // and back.
  long oldTime = 0;
  long traversalTime = 0;

  //Frame rate we will simulate in terms of the speed of
  // the sprite and maximum frame rate we will allow.
  // We will use this value to achieve a constant overall
  // speed of motion for the sprite regardless of the
  // actual frame rate.
  int targetFPS = 60;
  //----------------------------------------------------//

  public Slick0150b(){//constructor
    //Set the title
    super("Slick0150b, baldwin");
  }//end constructor
  //----------------------------------------------------//

  public static void main(String[] args)
                                    throws SlickException{
    AppGameContainer app = new AppGameContainer(
                          new Slick0150b(),414,307,false);
    app.start();
  }//end main
  //----------------------------------------------------//

  @Override
  public void init(GameContainer gc)
                                   throws SlickException {
    oldTime = gc.getTime();

    bug = new Image("ladybug.png");
    background = new Image("background.jpg");

    backgroundWidth = background.getWidth();
    backgroundHeight = background.getHeight();

    bugWidth = bug.getWidth()*bugScale;
    bugHeight = bug.getHeight()*bugScale;

    System.out.println(
                   "backgroundWidth: " + backgroundWidth);
    System.out.println(
                 "backgroundHeight: " + backgroundHeight);
    System.out.println("bugWidth: " + bugWidth);
    System.out.println("bugHeight: " + bugHeight);

    gc.setTargetFrameRate(targetFPS);//set frame rate
  }//end init
  //----------------------------------------------------//

  @Override
  public void update(GameContainer gc, int delta)
                                    throws SlickException{
    //Compute new location for the sprite.

    //The following code attempts to maintain a constant
    // overall speed as the bug moves across the game
    // window despite the fact that the delta varies
    // quite a bit from one frame to the next. The step
    // size varies in proportion to delta or inversely
    // with the frame rate.
    bugX += bugXDirection*xStep*delta*targetFPS/1000.0;
    bugY += bugYDirection*yStep*delta*targetFPS/1000.0;

    //The following code does not correct for variations
    // in delta. The step size is always the same
    // regardless of delta. Enable this code and disable
    // the two statements above to see the effect.
//    bugX += bugXDirection*xStep;
//    bugY += bugYDirection*yStep;

    //Test for collisions with the sides of the game
    // window and reverse direction when a collision
    // occurs.
    if(bugX+bugWidth >= backgroundWidth){
      //A collision has occurred.
      bugXDirection = -1.0f;//reverse direction
      //Set the position to the right edge less the width
      // of the sprite.
      bugX = backgroundWidth - bugWidth;

      //Compute traversal time for the bug to make one
      // round trip across the game window and back.
      long currentTime = gc.getTime();
      traversalTime = currentTime - oldTime;
      oldTime = currentTime;
    }//end if

    //Continue testing for collisions with the edges.
    if(bugX <= 0){
      bugXDirection = 1.0f;
      bugX = 0;
    }//end if

    if(bugY+bugHeight >= backgroundHeight){
      bugYDirection = -1.0f;
      bugY = backgroundHeight - bugHeight;
    }//end if

    if(bugY <= 0){
      bugYDirection = 1.0f;
      bugY = 0;
    }//end if

  }//end update
  //----------------------------------------------------//

  public void render(GameContainer gc, Graphics g)
                                    throws SlickException{
    //set the drawing mode to honor transparent pixels
    g.setDrawMode(g.MODE_NORMAL);//honors transparency

    //Draw the background to erase the previous picture.
    background.draw(0,0);

    //Draw the bug in its new location.
    bug.draw(bugX,bugY,bugScale);

    //Display the traversal time computed in the update
    // method.
    g.drawString(
                "traversalTime: "+traversalTime,100f,10f);

    //Insert an additional random time delay ranging from
    // 0 to 43 msec to simulate a situation where the
    // rendering process is very complex and the time
    // to render varies quite a lot from one frame to
    // the next. The average delay time should be about
    // 21.5 msec, which should result in an average FPS of
    // about 46 or 47 FPS reduced by the additional time
    // that would be required to complete a frame in the
    // absence of this time delay.
    int sleepTime = (((byte)random.nextInt()) + 128)/6;
    gc.sleep(sleepTime);

  }//end render

}//end class Slick0150b
//======================================================//